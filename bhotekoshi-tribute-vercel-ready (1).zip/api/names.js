const { setCorsHeaders } = require('../lib/cors');
const { getEntries } = require('../lib/store');

// Default password is 7671, as requested. For real use, set an
// ADMIN_PASSWORD environment variable in the Vercel project settings —
// that overrides this default without touching any code.
const DEFAULT_PASSWORD = '7671';

module.exports = async function handler(req, res) {
  setCorsHeaders(res);

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (req.method !== 'GET') {
    res.status(405).json({ error: 'Use GET to read names.' });
    return;
  }

  const expected = process.env.ADMIN_PASSWORD || DEFAULT_PASSWORD;
  const provided = req.query.password;

  if (provided !== expected) {
    res.status(401).json({ error: 'Incorrect password.' });
    return;
  }

  res.status(200).json({ entries: getEntries() });
};
