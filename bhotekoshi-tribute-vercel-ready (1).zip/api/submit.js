const { setCorsHeaders } = require('../lib/cors');
const { addEntry } = require('../lib/store');

module.exports = async function handler(req, res) {
  setCorsHeaders(res);

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Use POST to submit a name.' });
    return;
  }

  // Vercel usually parses JSON bodies for us. Handle the rare case where
  // it arrives as a raw string too.
  let body = req.body;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch {
      body = {};
    }
  }
  body = body || {};

  const rawName = typeof body.name === 'string' ? body.name : '';
  const name = rawName.trim().replace(/[<>]/g, '').slice(0, 80);

  if (!name) {
    res.status(400).json({ error: 'A name is required.' });
    return;
  }

  addEntry(name);
  res.status(200).json({ ok: true });
};
