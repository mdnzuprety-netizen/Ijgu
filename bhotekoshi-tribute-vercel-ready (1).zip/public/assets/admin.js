// 🔧 REPLACE ME after you deploy the backend project — same value as in main.js.
const API_BASE = ""; // same origin: API lives in the same Vercel project

const form = document.getElementById("password-form");
const passwordInput = document.getElementById("admin-password");
const passwordError = document.getElementById("password-error");
const results = document.getElementById("results");

function formatTime(iso) {
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

function renderEntries(entries) {
  results.innerHTML = "";

  if (!entries.length) {
    const p = document.createElement("p");
    p.className = "log-empty";
    p.textContent = "No one has lit a candle yet.";
    results.appendChild(p);
    return;
  }

  const list = document.createElement("ul");
  list.className = "log-list";

  entries.forEach((entry) => {
    const item = document.createElement("li");

    const nameSpan = document.createElement("span");
    nameSpan.className = "name";
    nameSpan.textContent = entry.name; // textContent, not innerHTML — safe from injection

    const timeSpan = document.createElement("span");
    timeSpan.className = "time";
    timeSpan.textContent = formatTime(entry.submittedAt);

    item.appendChild(nameSpan);
    item.appendChild(timeSpan);
    list.appendChild(item);
  });

  results.appendChild(list);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  passwordError.textContent = "";
  results.innerHTML = "";

  const password = passwordInput.value;
  const submitButton = form.querySelector("button");
  submitButton.disabled = true;
  submitButton.textContent = "Checking…";

  try {
    const res = await fetch(
      `${API_BASE}/api/names?password=${encodeURIComponent(password)}`
    );

    if (res.status === 401) {
      passwordError.textContent = "Incorrect password.";
      return;
    }

    if (!res.ok) {
      passwordError.textContent = "Something went wrong. Try again.";
      return;
    }

    const data = await res.json();
    renderEntries(data.entries || []);
  } catch (err) {
    console.error(err);
    passwordError.textContent = "Couldn't reach the server. Try again.";
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "View log";
  }
});
