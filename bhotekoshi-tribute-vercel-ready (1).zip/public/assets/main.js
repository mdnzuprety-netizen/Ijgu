// 🔧 REPLACE ME after you deploy the backend project.
// Example: "https://bhotekoshi-tribute-backend.vercel.app"
const API_BASE = ""; // same origin: API lives in the same Vercel project

const nameForm = document.getElementById("name-form");
const nameInput = document.getElementById("visitor-name");
const nameError = document.getElementById("name-error");
const viewName = document.getElementById("view-name");
const viewTribute = document.getElementById("view-tribute");
const tributeHeading = document.getElementById("tribute-heading");

async function submitName(name) {
  const res = await fetch(`${API_BASE}/api/submit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) {
    throw new Error("Server responded with an error.");
  }
}

function showTribute(name) {
  tributeHeading.textContent = `Thank you, ${name}.`;
  viewName.classList.add("hidden");
  viewTribute.classList.remove("hidden");
  viewTribute.setAttribute("tabindex", "-1");
  viewTribute.focus();
}

nameForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  nameError.textContent = "";

  const name = nameInput.value.trim();
  if (!name) {
    nameError.textContent = "Please enter a name.";
    return;
  }

  const submitButton = nameForm.querySelector("button");
  submitButton.disabled = true;
  submitButton.textContent = "Lighting…";

  try {
    await submitName(name);
  } catch (err) {
    // We still let the visitor see the tribute even if saving the name
    // failed — the tribute itself matters more than the record of it.
    console.error("Could not save name:", err);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Light a candle";
  }

  showTribute(name);
});
